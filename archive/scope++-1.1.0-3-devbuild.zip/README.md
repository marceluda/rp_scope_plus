# rp_scope_plus
Extended Scope app for the Red Pitaya enviroment.

Based in [Scope App v0.95](https://github.com/RedPitaya/RedPitaya/tree/release-v0.95/apps-free/scope)
of community applications for Red Pitaya Project.
